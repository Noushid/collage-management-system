<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<titl</title>
</head>
<body>
<form name="about"action="" method="post">

	<h1><center>WELCOME TO COLLEGE MANAGEMENT SYSTEM<br>&<br> SCIENCE COLLEGE ONLNE</h1></center>
				PICTURE
	<p><center>College Management System deals with all kind of student details, academic related reports, college details, course details, curriculum, batch details and other resource related details too. It tracks all the details of a student from the day one to the end of his course which can be used for all reporting purpose, tracking of attendance, progress in the course, completed semesters years, coming semester year curriculum details, exam details, project or any other assignment details, final exam result; and all these will be available for future references too.Our program will have the databases of Courses offered by the college under all levels of graduation or main streams, teacher or faculty's details, batch execution details, students' details in all aspects.This program can facilitate us explore all the activities happening in the college, even we can get to know which teacher / faculty is assigned to which batch, the current status of a batch, attendance percentage of a batch and upcoming requirements of a batch. Different reports and Queries can be generated based of vast options related to students, batch, course, teacher / faculty, exams, semesters, certification and even for the entire college.</center><br/><br/>

	 <center> college management system is a self financing college recognized by the Govt of Kerala and affilicated to the University of Calicut.It is run by the Jamia Nadwiyya Trust board, Edavanna.The College was established in 2003 with a main objective of uplifting the educationally back ward muslims other back ward communities in particular and all other communities in general,moulding them professionally competent,socially responsible and morally citizens</center> </p>
	 
	 <center> <h1>LIFE AND JAMIA </h1></center>
	    PCTURE
	  <p><center>Various educational, sports, cultural, social and religious activities are avlailable to JNASC students and staff.
	  involment in our campus life.....</center></p>

	 <center> <h1> CAREERS</h1></center>
	  		PICTURE
	<center>  <P>Working with college management system offers you peace of mind. A highly talented and experianced oarganization to provide you support and motivation for your career</P></center>
	  <form>s
	   </body>
</html>